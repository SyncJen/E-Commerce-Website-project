package com.KartStyle;

import com.KartStyle.model.Product;
import com.KartStyle.respository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class KartStyleApplication {

	public static void main(String[] args) {
		SpringApplication.run(KartStyleApplication.class, args);
	}

	@Bean
	CommandLineRunner run(ProductRepository productRepository) {
		return args -> {
			if (productRepository.count() == 0) { // ✅ check before inserting
				List<Product> products = List.of(
						// Men
						new Product(null, "Graphic T-Shirt", "men", "Printed round neck T-shirt", 699.00, "/images/graphic-tshirt-round-neck.jpg"),
						new Product(null, "Denim Shirt", "men", "Slim fit blue denim shirt", 1299.00, "/images/Denim-shirt-blue.jpg"),
						new Product(null, "Regular Fit Jeans", "men", "Mid-rise dark blue jeans", 999.00, "/images/Slim-Fit-Jeans-men.webp"),
						new Product(null, "Hooded Jacket", "men", "Black zip-up hoodie jacket", 1499.00, "/images/zip-up-hoodie-men.webp"),
						new Product(null, "Ethnic Kurta Set", "men", "Ethnic cotton kurta set", 1199.00, "/images/Ethnic-Kurta-Men.webp"),

						// Women
						new Product(null, "Floral Kurti", "women", "Printed A-line cotton kurti", 749.00, "/images/Floral-Kurti-Women.webp"),
						new Product(null, "Peplum Top", "women", "Chiffon peplum top", 899.00, "/images/Peplum-Top-Women.webp"),
						new Product(null, "Skater Dress", "women", "Fit & flare skater dress", 1290.00, "/images/Skater-Dress-Women.webp"),
						new Product(null, "Silk Saree", "women", "Red silk saree with zari border", 1499.00, "/images/Silk-Saree-Women.webp"),
						new Product(null, "Distressed Jeans", "women", "High-waist distressed jeans", 1199.00, "/images/High-Waist-Jeans-women.webp")
				);

				productRepository.saveAll(products);
			}
		};
	}
}
