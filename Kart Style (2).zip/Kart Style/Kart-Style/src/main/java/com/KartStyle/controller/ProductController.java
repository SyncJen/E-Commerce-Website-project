package com.KartStyle.controller;

import com.KartStyle.model.Product;
import com.KartStyle.service.ProductService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*") // Allow cross-origin requests
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // GET: fetch all products
    @GetMapping
    public List<Product> getAll() {
        return productService.getAllProducts();
    }

    // GET: fetch product by ID
    @GetMapping("/{id}")
    public Product getById(@PathVariable Long id) {
        return productService.getProductById(id);
    }

    // GET: fetch products by category (generic)
    @GetMapping("/category/{category}")
    public List<Product> getByCategory(@PathVariable String category) {
        return productService.getByCategory(category);
    }

    // GET: fetch only men's products
    @GetMapping("/men")
    public List<Product> getMenProducts() {
        return productService.getByCategory("men");
    }

    // GET: fetch only women's products
    @GetMapping("/women")
    public List<Product> getWomenProducts() {
        return productService.getByCategory("women");
    }

    // POST: create a new product
    @PostMapping
    public Product create(@RequestBody Product product) {
        return productService.addProduct(product);
    }

    // DELETE: delete product by ID
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        productService.deleteProduct(id);
    }
}
