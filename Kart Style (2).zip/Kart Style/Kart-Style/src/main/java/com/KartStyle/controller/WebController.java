package com.KartStyle.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
    @GetMapping("/")
    public String home(){
        return "openpage.html";
    }

    @GetMapping("/checkout")
    public String page(){
        return "checkout.html";
    }

    @GetMapping("/dispatch_confirm")
    public String dispatchcon(){
        return "dispatch_confirm";
    }

}
