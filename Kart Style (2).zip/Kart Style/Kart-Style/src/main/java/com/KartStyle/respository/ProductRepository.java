package com.KartStyle.respository;

import com.KartStyle.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    // Custom method to find products by category (e.g., "men", "women")
    List<Product> findByCategory(String category);
}
